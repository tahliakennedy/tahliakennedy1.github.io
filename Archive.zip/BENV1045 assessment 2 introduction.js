(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"BENV1045 assessment 2 introduction_atlas_1", frames: [[1258,1257,738,92],[869,1351,738,92],[0,1352,738,92],[0,1258,867,92],[0,0,627,627],[629,0,627,627],[1258,0,627,627],[0,629,627,627],[629,629,627,627],[1258,629,627,626]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_4 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._6PrinciplesInfographicpt1 = function() {
	this.initialize(img._6PrinciplesInfographicpt1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1006,2169);


(lib._6PrinciplesInfographicpt2 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._6PrinciplesInfographicpt3pngcopy = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._6PrinciplesInfographicpt4 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib._6PrinciplesInfographicpt5 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib._6PrinciplesInfographicpt6 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib._6PrinciplesInfographicpt7 = function() {
	this.initialize(ss["BENV1045 assessment 2 introduction_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.leafcharacter1 = function() {
	this.initialize(img.leafcharacter1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3256,2384);


// stage content:
(lib.BENV1045assessment2introduction = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// _
	this.instance = new lib._6PrinciplesInfographicpt2();
	this.instance.setTransform(477,309,0.1375,0.1375);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(159).to({_off:false},0).to({_off:true},44).wait(43));

	// _
	this.instance_1 = new lib._6PrinciplesInfographicpt3pngcopy();
	this.instance_1.setTransform(506,213,0.1343,0.1343);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(149).to({_off:false},0).to({_off:true},54).wait(43));

	// _
	this.instance_2 = new lib._6PrinciplesInfographicpt4();
	this.instance_2.setTransform(420,127,0.1375,0.1375);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(139).to({_off:false},0).to({_off:true},64).wait(43));

	// _d
	this.instance_3 = new lib._6PrinciplesInfographicpt5();
	this.instance_3.setTransform(290,127,0.1311,0.1311);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(129).to({_off:false},0).to({_off:true},74).wait(43));

	// _nd
	this.instance_4 = new lib._6PrinciplesInfographicpt6();
	this.instance_4.setTransform(213,209,0.1343,0.1343);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(119).to({_off:false},0).to({_off:true},84).wait(43));

	// _st_principle
	this.instance_5 = new lib._6PrinciplesInfographicpt7();
	this.instance_5.setTransform(243,309,0.1375,0.1375);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(109).to({_off:false},0).to({_off:true},94).wait(43));

	// branch
	this.instance_6 = new lib._6PrinciplesInfographicpt1();
	this.instance_6.setTransform(304,213,0.1717,0.1717);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(100).to({_off:false},0).wait(102).to({_off:true},1).wait(43));

	// text
	this.instance_7 = new lib.CachedBmp_1();
	this.instance_7.setTransform(205.9,127.75,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_2();
	this.instance_8.setTransform(211.05,43.65,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_3();
	this.instance_9.setTransform(211.05,33.65,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_4();
	this.instance_10.setTransform(211.05,33.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},29).to({state:[{t:this.instance_8}]},46).to({state:[{t:this.instance_9}]},26).to({state:[{t:this.instance_10}]},30).to({state:[]},68).wait(47));

	// speech_bubble
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(229,210,184,0.6)").s().p("EgwCAGvQh8AAhYhYQhYhYAAh8IAAkFQAAh8BYhYQBYhYB8AAMBgFAAAQB8AABYBYQBYBYAAB8IAAEFQAAB8hYBYQhYBYh8AAg");
	this.shape.setTransform(425.65,154.625);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(14).to({_off:false},0).to({_off:true},61).wait(171));

	// leaf_guy
	this.instance_11 = new lib.leafcharacter1();
	this.instance_11.setTransform(-308,64,0.2002,0.2002);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({_off:true},75).wait(171));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E5E0D8").s().p("Eg+pAu9MAAAhd5MB9TAAAMAAABd5g");
	this.shape_1.setTransform(399.025,299.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(202).to({_off:true},1).wait(43));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,800,600);
// library properties:
lib.properties = {
	id: 'F4A53FD4F51B504AB08144A29DC985DF',
	width: 800,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_6PrinciplesInfographicpt1.png", id:"_6PrinciplesInfographicpt1"},
		{src:"images/leafcharacter1.png", id:"leafcharacter1"},
		{src:"images/BENV1045 assessment 2 introduction_atlas_1.png", id:"BENV1045 assessment 2 introduction_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F4A53FD4F51B504AB08144A29DC985DF'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;